# RANIA AI — LU SANIMAR Travel Intelligence

RANIA AI adalah asisten travel berbasis AI untuk LU SANIMAR Travel, Timor-Leste. Membantu pengguna mencari tiket pesawat, booking, info visa, hotel, dan layanan travel 24/7 dalam 4 bahasa (Tetun, Indonesia, English, Português).

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, path /api)
- `pnpm --filter @workspace/rania-chat run dev` — run the frontend (port 25049, path /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 (artifacts/api-server, port 8080, path /api)
- Frontend: React + Vite (artifacts/rania-chat, port 25049, path /)
- DB: PostgreSQL + Drizzle ORM
- AI: Groq (primary), Cerebras, Gemini, Cloudflare Workers AI (fallbacks)
- Voice: ElevenLabs TTS
- Email: Resend
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/routes/rania.ts` — main 7400+ line monolith: RANIA_SYSTEM prompt, chat handler, all endpoints
- `artifacts/api-server/src/routes/admin.ts` — admin dashboard routes
- `artifacts/api-server/src/routes/cqap.ts` — CQAP routes
- `artifacts/rania-chat/src/pages/Home.tsx` — main home page with chat, radar, price chart
- `artifacts/rania-chat/src/components/LiveFlightRadar.tsx` — Leaflet live flight radar
- `lib/db/src/schema/` — DB schema (bookings, partners, qa-runs)

## Architecture decisions

- Single-file API monolith (rania.ts) for simplicity — all RANIA logic in one place
- Multi-provider AI fallback chain: Groq → Cerebras → Gemini → Cloudflare
- GROQ_API_KEY_2 for secondary Groq instance with faster model (llama-3.1-8b-instant)
- Path-based routing: /api → API server, / → React frontend
- 4-language support: Tetun (tet), Bahasa Indonesia (id), English (en), Português (pt)

## Product

- AI chat travel assistant (RANIA) via floating chat button
- Live flight radar (Leaflet map + AviationStack)
- Flight price history chart (30-day)
- Booking flow with passenger details, payment, e-ticket via Resend email
- WhatsApp notification via CallMeBot
- Admin dashboard, staff monitor, test lab
- Splash screen with animated globe

## User preferences

- Aktivkan semua API key dan fitur sekaligus
- Tampilkan halaman/page aplikasi (frontend)

## Gotchas

- DB hydration warning on start is normal if DB is empty — tidak masalah
- GRU duplicate key warning in rania.ts build — just a warning, tidak mempengaruhi fungsi
- rania.ts adalah file monolith besar (7400+ baris) — edit dengan hati-hati

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- API keys yang digunakan: GROQ_API_KEY, GROQ_API_KEY_2, GEMINI_API_KEY, CEREBRAS_KEY, CLOUDFLARE_API_TOKEN, CLOUDFLARE_ACCOUNT_ID, ELEVENLABS_API_KEY, RESEND_API_KEY, AVIATIONSTACK_KEY, TRAVELPAYOUTS_TOKEN, TRAVELPAYOUTS_MARKER, RAPIDAPI_KEY, WHATSAPP_CALLMEBOT_KEYAPI
