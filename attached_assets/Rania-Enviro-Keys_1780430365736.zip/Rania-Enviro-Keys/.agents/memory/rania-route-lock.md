---
name: RANIA Route-Lock & Date Gate Fix
description: How the flight date gate and AI route-lock work, and what was fixed
---

## The problem
RANIA was asking "Dari kota mana?" / "Tanggal berapa?" even when user clearly stated both cities AND date in one message (e.g. "New York ke London 15 Juli").

## Root cause
1. `hasCity` regex at date gate (rania.ts ~line 4176) only had ~15 cities — missed Tokyo, Paris, Rome, etc.
2. RANIA_SYSTEM prompt lacked an INSTANT SEARCH RULE instructing AI to output JSON immediately when all 3 info items present.

## Fix applied
1. Expanded `hasCity` regex to 50+ cities + added `|| intentRouteExtracted.length >= 2` so gate is bypassed when `extractCitiesAsIATA` already found ≥2 airports.
2. Added section "## 7b. ⚡ INSTANT SEARCH RULE" to RANIA_SYSTEM with explicit examples + city→IATA quick reference table.

**Why:** The date gate only checks `!hasDepartureDateMention` — if date IS present it's skipped, but then the AI itself was still asking clarifying questions due to missing explicit rule.

**How to apply:** If RANIA still asks again for a route+date already in the message, check: (a) `hasDepartureDateMention` regex covers the language used, (b) INSTANT SEARCH RULE examples in section 7b cover the pattern.
