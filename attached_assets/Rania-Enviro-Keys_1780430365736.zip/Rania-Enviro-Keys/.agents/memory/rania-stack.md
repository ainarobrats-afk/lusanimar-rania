---
name: RANIA AI Stack
description: Tech stack, key files, and env secrets for the RANIA travel assistant app
---

## Stack
- pnpm monorepo, Node.js 24, TypeScript 5.9
- API: Express 5 at artifacts/api-server (port 8080, path /api)
- Frontend: React+Vite at artifacts/rania-chat (path /)
- DB: PostgreSQL + Drizzle ORM
- AI: Groq (primary), Cerebras, Gemini (fallbacks)

## Key files
- `artifacts/api-server/src/routes/rania.ts` — 7400+ line monolith: RANIA_SYSTEM prompt, chat handler, all endpoints
- `artifacts/rania-chat/src/components/LiveFlightRadar.tsx` — Leaflet radar + DIL flights panel
- `artifacts/rania-chat/src/pages/Home.tsx` — main home page embedding radar

## Secrets used
AVIATIONSTACK_KEY, TRAVELPAYOUTS_TOKEN, GROQ_API_KEY, GROQ_API_KEY_2, GEMINI_API_KEY, CEREBRAS_KEY, ELEVENLABS_API_KEY, RESEND_API_KEY, WHATSAPP_CALLMEBOT_KEYAPI, SESSION_SECRET, CLOUDFLARE_API_TOKEN, CLOUDFLARE_ACCOUNT_ID

## Env vars set
RESEND_FROM_EMAIL=info.lusanimar@gmail.com, WHATSAPP_CALLMEBOT_PHONE=75143965
