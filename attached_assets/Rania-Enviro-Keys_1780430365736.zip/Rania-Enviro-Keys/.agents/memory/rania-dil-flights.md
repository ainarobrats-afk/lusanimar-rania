---
name: RANIA DIL Flights Endpoint
description: AviationStack live departures/arrivals endpoint for Dili airport
---

## Endpoint
GET /api/rania/dil-flights

## Implementation (rania.ts ~line 6818)
- Fetches AviationStack /v1/flights?dep_iata=DIL and /v1/flights?arr_iata=DIL in parallel
- Module-level `dilFlightsCache` with 10-minute TTL (AviationStack free tier = 100 req/month)
- Falls back to hardcoded Aero Dili + Garuda schedule if API fails
- Returns: { departures[], arrivals[], source, cached, ts }

## Frontend (LiveFlightRadar.tsx)
- Tabbed panel below the Leaflet radar map showing 🛫 Departures / 🛬 Arrivals
- Refreshes every 5 minutes
- Status badge: "LIVE AviationStack" (green pulse) vs "Schedule (offline)" (yellow)
- FlightRow: flight#, airline, destination IATA+name, scheduled time, delay, gate

**Why:** AviationStack free tier has only 100 req/month — 10-min server cache prevents exhaustion. OpenSky (radar) is separate and has no key requirement.
